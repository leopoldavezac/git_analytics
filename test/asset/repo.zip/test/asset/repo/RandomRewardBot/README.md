# RandomRewardBot
(bot) - a bot that gives (or not) random rewards
